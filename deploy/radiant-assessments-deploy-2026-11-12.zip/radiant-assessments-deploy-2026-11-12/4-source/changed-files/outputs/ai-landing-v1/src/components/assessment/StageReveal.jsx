import { motion } from 'framer-motion'
import { c, tone, alpha } from '../../theme/tokens'

/**
 * Maturity reveal panel: name, tagline, description, and a progression visual.
 *
 * Used by both assessments:
 *   AI: pass `stages` (the 5 named stages) → renders an ascending staircase
 *       (increasing-height bars) with the current stage highlighted.
 *   CX: omit `stages` → renders the simple N-pip meter (3 levels).
 *
 * Props:
 *   stage   { name, index, tagline, description }
 *   accent
 *   total   number of pips for the pip-meter fallback (default 5)
 *   kicker  label above the heading (default "Your AI Maturity")
 *   prefix  heading prefix; defaults to `Stage {index}`. Pass "" for none.
 *   stages  optional [{ index, name, tagline }]: when present, render the staircase
 *   noun    word used in the staircase footnote/aria ("Stage" for AI, "Level" for CX)
 *   note    optional override for the staircase footnote text
 *
 * Stage states are distinguished by fill, border and weight. Every label stays at
 * text-muted or stronger (≥4.5:1); dimming text with opacity failed AA.
 */
export default function StageReveal({ stage, accent: accentProp = '#91C46B', total = 5, kicker = 'Your AI Maturity', prefix, stages, noun = 'Stage', note }) {
  const accent = tone(accentProp)
  const head = prefix === undefined ? `Stage ${stage.index}` : prefix
  const useStaircase = Array.isArray(stages) && stages.length > 0

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
      className="mag-card p-8 lg:p-10 relative overflow-hidden"
    >
      <div className="absolute inset-0 pointer-events-none"
        style={{ background: `radial-gradient(ellipse at 0% 0%, ${alpha(accent, 6)} 0%, transparent 55%)` }} />
      <div className="relative z-10">
        <span className="kicker mb-4">{kicker}</span>
        <div className="flex flex-wrap items-end gap-x-4 gap-y-2 mb-5">
          <h2 className="font-display font-black text-ink tracking-tight leading-[0.9]"
            style={{ fontSize: 'clamp(2.4rem, 5vw, 3.6rem)' }}>
            {head ? `${head}: ` : ''}<span style={{ color: accent }}>{stage.name}</span>
          </h2>
        </div>
        {stage.tagline && <p className="text-text-secondary font-semibold mb-6">{stage.tagline}</p>}

        {useStaircase
          ? <Staircase stages={stages} currentIndex={stage.index} accent={accent} noun={noun} note={note} />
          : <PipMeter index={stage.index} total={total} accent={accent} />}

        {stage.description && <p className="text-text-secondary text-base lg:text-lg leading-[1.85]">{stage.description}</p>}
      </div>
    </motion.div>
  )
}

/* ── Pip meter (CX, and any non-staircase use) ───────────────────────────── */
function PipMeter({ index, total, accent }) {
  return (
    <div className="flex items-center gap-2 mb-7" role="img" aria-label={`Level ${index} of ${total}`}>
      {Array.from({ length: total }, (_, i) => i + 1).map(n => (
        <motion.div key={n}
          initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 0.1 * n, duration: 0.4 }}
          className="h-2.5 flex-1 rounded-full origin-left"
          style={{ background: n <= index ? accent : c('track') }} />
      ))}
    </div>
  )
}

/* ── Ascending staircase (AI): bars grow taller left → right ─────────────── */
function Staircase({ stages, currentIndex, accent, noun = 'Stage', note }) {
  const total = stages.length
  const footnote = note ?? (currentIndex < total
    ? `Most organizations take 12-18 months to move from ${noun} ${currentIndex} to ${noun} ${currentIndex + 1}.`
    : "You're at the top of the maturity curve, the focus now is compounding the advantage.")

  return (
    <div className="mb-7" role="img" aria-label={`${noun} ${currentIndex} of ${total}`}>
      {/* Desktop / tablet: ascending bars, explicit increasing pixel heights so
          every step is visibly taller than the one before it. The "You are here"
          marker is absolutely positioned so it never compresses the current bar. */}
      <div className="hidden sm:block">
        <div className="flex items-end gap-2.5" style={{ height: 210 }}>
          {stages.map((s, i) => {
            const isPast = s.index < currentIndex
            const isCurrent = s.index === currentIndex
            // Even steps from 70 → 190 regardless of count (6 stages → 24px/step, 3 levels → 60px/step)
            const barH = 70 + i * (total > 1 ? (190 - 70) / (total - 1) : 0)

            return (
              <motion.div key={s.key || s.index}
                className="flex-1 relative h-full flex items-end"
                initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
              >
                {isCurrent && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.45 }}
                    className="absolute left-0 right-0 text-center" style={{ bottom: barH + 8 }}
                  >
                    <div className="text-[10px] font-display font-bold uppercase tracking-widest mb-1" style={{ color: accent }}>
                      You are here
                    </div>
                    <div className="w-0 h-0 mx-auto" style={{
                      borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: `5px solid ${accent}`,
                    }} />
                  </motion.div>
                )}

                <div
                  className="w-full rounded-t-lg relative overflow-hidden flex flex-col items-center justify-end pb-3"
                  style={{
                    height: barH,
                    background: isCurrent
                      ? `linear-gradient(180deg, ${alpha(accent, 22)} 0%, ${alpha(accent, 12)} 100%)`
                      : isPast ? alpha(accent, 9) : c('surface-2'),
                    border: `1px solid ${isCurrent ? accent : isPast ? alpha(accent, 35) : c('border')}`,
                    borderBottom: 'none',
                  }}
                >
                  {isCurrent && (
                    <div className="absolute inset-0 pointer-events-none"
                      style={{ background: `linear-gradient(180deg, ${alpha(accent, 6)} 0%, transparent 60%)` }} />
                  )}
                  <div className="relative z-10 text-center px-1">
                    <div className="font-display font-black text-lg leading-none mb-0.5"
                      style={{ color: isCurrent || isPast ? accent : c('text-muted') }}>
                      {s.index}
                    </div>
                    <div className="font-display font-bold text-xs leading-tight"
                      style={{ color: isCurrent ? c('ink') : isPast ? c('text-secondary') : c('text-muted') }}>
                      {s.name}
                    </div>
                  </div>
                </div>
              </motion.div>
            )
          })}
        </div>

        {/* Taglines row: separate from the bars so they don't affect bar heights */}
        <div className="flex gap-2.5 mt-2">
          {stages.map((s) => {
            const isCurrent = s.index === currentIndex
            return (
              <p key={s.key || s.index} className={`flex-1 text-[11px] leading-snug text-center px-0.5 ${isCurrent ? 'font-semibold' : ''}`}
                style={{ color: isCurrent ? c('text-secondary') : c('text-muted') }}>
                {s.tagline}
              </p>
            )
          })}
        </div>
      </div>

      {/* Mobile: vertical list */}
      <div className="sm:hidden space-y-2">
        {stages.map((s, i) => {
          const isPast = s.index < currentIndex
          const isCurrent = s.index === currentIndex
          return (
            <motion.div key={s.key || s.index}
              initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4, delay: i * 0.06 }}
              className="flex items-center gap-3 p-3 rounded-xl"
              style={{
                background: isCurrent ? alpha(accent, 10) : c('surface-2'),
                border: `1px solid ${isCurrent ? accent : c('border')}`,
              }}
            >
              <div className="w-8 h-8 rounded-lg flex items-center justify-center font-display font-black text-sm flex-shrink-0"
                style={{
                  background: isCurrent ? alpha(accent, 18) : isPast ? alpha(accent, 9) : c('surface-1'),
                  color: isCurrent || isPast ? accent : c('text-muted'),
                }}>
                {s.index}
              </div>
              <div className="flex-1">
                <div className="font-display font-bold text-sm"
                  style={{ color: isCurrent ? c('ink') : isPast ? c('text-secondary') : c('text-muted') }}>
                  {s.name}
                  {isCurrent && <span className="ml-2 text-[11px] font-bold uppercase tracking-wider" style={{ color: accent }}>← You</span>}
                </div>
                {s.tagline && (
                  <div className="text-[12px] mt-0.5" style={{ color: isCurrent ? c('text-secondary') : c('text-muted') }}>
                    {s.tagline}
                  </div>
                )}
              </div>
            </motion.div>
          )
        })}
      </div>

      <p className="text-text-muted text-xs mt-4 leading-relaxed">{footnote}</p>
    </div>
  )
}
