<?php
/**
 * Public entry point for POST /api/assessment-report (PHP option).
 * The only file of the PHP mailer that sits inside the web root.
 *
 * EDIT THIS ONE LINE if the app folder lives somewhere else. It must point to
 * the radiant-assessment-mailer folder OUTSIDE the web root.
 */
$appDir = getenv('RADIANT_ASSESSMENT_APP_DIR') ?: '/var/www/radiant-assessment-mailer';

require $appDir . '/bootstrap.php';

(new RadiantAssessment\ReportEndpoint(radiant_assessment_config()))->handle();
