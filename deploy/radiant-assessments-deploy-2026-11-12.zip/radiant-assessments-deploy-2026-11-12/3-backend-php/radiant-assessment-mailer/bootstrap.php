<?php
/**
 * Loads dependencies and configuration for the assessment report endpoint.
 * Lives OUTSIDE the web root. The public entry file (api/assessment-report.php)
 * requires this file.
 */

if (PHP_VERSION_ID < 70400) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo '{"error":"server_php_version"}';
    error_log('[radiant-assessment] PHP 7.4+ required, found ' . PHP_VERSION);
    exit;
}

$autoload = __DIR__ . '/vendor/autoload.php';
if (!is_file($autoload)) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo '{"error":"server_dependencies_missing"}';
    error_log('[radiant-assessment] vendor/autoload.php missing: run "composer install --no-dev" in ' . __DIR__);
    exit;
}
require $autoload;

require __DIR__ . '/src/ReportRouting.php';
require __DIR__ . '/src/Templates.php';
require __DIR__ . '/src/RateLimiter.php';
require __DIR__ . '/src/ReportMailer.php';
require __DIR__ . '/src/ReportEndpoint.php';

/**
 * Configuration. Each value comes from config.php (if present, outside the web
 * root, never committed) and falls back to the environment variable of the
 * same name (e.g. Apache "SetEnv SMTP_HOST ..."), using the SAME names as the
 * Node API's .env so existing values can be reused.
 */
function radiant_assessment_config(): array
{
    $file = __DIR__ . '/config.php';
    $local = is_file($file) ? (array) require $file : [];
    $get = function ($key, $default = '') use ($local) {
        if (array_key_exists($key, $local) && $local[$key] !== null) {
            return (string) $local[$key];
        }
        $env = getenv($key);
        return ($env === false) ? $default : (string) $env;
    };

    $secure = strtolower($get('SMTP_SECURE', 'false')) === 'true';
    $encryption = strtolower($get('SMTP_ENCRYPTION', ''));      // PHP-only override: starttls | ssl | none
    if (!in_array($encryption, ['starttls', 'ssl', 'none'], true)) {
        $encryption = $secure ? 'ssl' : 'starttls';
    }

    return [
        'SMTP_HOST'           => $get('SMTP_HOST'),
        'SMTP_PORT'           => $get('SMTP_PORT', '587'),
        'SMTP_USER'           => $get('SMTP_USER'),
        'SMTP_PASS'           => $get('SMTP_PASS'),
        'MAIL_FROM'           => $get('MAIL_FROM'),
        'MAIL_CC'             => $get('MAIL_CC'),
        'REPORT_NOTIFY_EMAIL' => $get('REPORT_NOTIFY_EMAIL'),
        'FRONTEND_URL'        => $get('FRONTEND_URL'),
        'encryption'          => $encryption,
        'RATE_LIMIT_DIR'      => $get('RATE_LIMIT_DIR', rtrim(sys_get_temp_dir(), '/') . '/radiant-assessment-ratelimit'),
        'CLIENT_IP_HEADER'    => $get('CLIENT_IP_HEADER'),
    ];
}
