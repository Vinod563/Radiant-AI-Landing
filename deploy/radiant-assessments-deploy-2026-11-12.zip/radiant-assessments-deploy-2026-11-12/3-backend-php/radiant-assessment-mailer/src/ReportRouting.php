<?php
/**
 * Fixed, per-assessment recipients for report emails.
 *
 * PHP port of REPORT_ROUTING in outputs/radiant-chat-api/utils/mailer.js
 * (commit bd72760, approved 2026-11-12). Keyed by the exact `assessment`
 * value the website sends. Deliberately NOT read from config/env, so the live
 * server cannot drift from what was agreed. Change it only with sign-off and
 * keep it identical to mailer.js.
 *
 * The sender is always MAIL_FROM from config.
 */

namespace RadiantAssessment;

final class ReportRouting
{
    /** @return array<string, array{respondentBcc: string[], teamTo: string[], teamCc: string[]}> */
    public static function table(): array
    {
        $leadsTeam = [
            'lam.huynh@radiant.digital',
            'alek.nedelkovski@radiant.digital',
            'vinod.mourya@radiant.digital',
        ];

        return [
            'AI Maturity' => [
                // BCC on the respondent's PDF email
                'respondentBcc' => $leadsTeam,
                // "New AI Maturity lead — [name]"
                'teamTo' => ['connect@radiant.digital', 'hello@radiant.digital'],
                'teamCc' => $leadsTeam,
            ],
            'CX Maturity' => [
                // BCC on the respondent's PDF email
                'respondentBcc' => [
                    'lam.huynh@radiant.digital',
                    'elizabeth.holland@radiant.digital',
                ],
                // "New CX Maturity lead — [name]"
                'teamTo' => ['connect@radiant.digital', 'hello@radiant.digital'],
                'teamCc' => [
                    'lam.huynh@radiant.digital',
                    'elizabeth.holland@radiant.digital',
                    'tushar.hande@radiant.digital',
                    'deena.bhattacharjee@radiant.digital',
                ],
            ],
        ];
    }

    public static function forAssessment(string $assessment): ?array
    {
        $table = self::table();
        return isset($table[$assessment]) ? $table[$assessment] : null;
    }
}
