<?php
/**
 * Fixed-window rate limiter backed by small files (no database needed).
 * Mirrors the Node reportLimiter: 10 requests per hour per client IP.
 */

namespace RadiantAssessment;

final class RateLimiter
{
    /** @var string */
    private $dir;
    /** @var int */
    private $max;
    /** @var int */
    private $windowSeconds;

    public function __construct(string $dir, int $max = 10, int $windowSeconds = 3600)
    {
        $this->dir = rtrim($dir, '/');
        $this->max = $max;
        $this->windowSeconds = $windowSeconds;
    }

    /** Records a hit; returns false when the client is over the limit. Fails open if storage is unavailable. */
    public function hit(string $clientKey): bool
    {
        if (!is_dir($this->dir) && !@mkdir($this->dir, 0700, true)) {
            error_log('[radiant-assessment] rate-limit dir not writable: ' . $this->dir);
            return true;
        }
        $file = $this->dir . '/' . hash('sha256', $clientKey) . '.json';
        $fh = @fopen($file, 'c+');
        if ($fh === false) {
            return true;
        }
        try {
            flock($fh, LOCK_EX);
            $now = time();
            $state = json_decode((string) stream_get_contents($fh), true);
            if (!is_array($state) || !isset($state['start'], $state['count']) || $now - (int) $state['start'] >= $this->windowSeconds) {
                $state = ['start' => $now, 'count' => 0];
            }
            $state['count']++;
            ftruncate($fh, 0);
            rewind($fh);
            fwrite($fh, json_encode($state));
            fflush($fh);
            return $state['count'] <= $this->max;
        } finally {
            flock($fh, LOCK_UN);
            fclose($fh);
        }
    }
}
