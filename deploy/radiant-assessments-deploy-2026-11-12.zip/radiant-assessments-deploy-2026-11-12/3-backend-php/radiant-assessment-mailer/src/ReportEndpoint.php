<?php
/**
 * POST /api/assessment-report
 *
 * PHP port of the Node route in outputs/radiant-chat-api/index.js. Same request,
 * same validation, same responses, so the website needs no change:
 *
 *   200 {"ok":true}                      sent (or honeypot hit)
 *   400 {"error":"A valid email is required"}
 *   400 {"error":"A valid report attachment is required"}
 *   403 {"error":"CORS blocked"}         cross-origin request from an origin not allowed
 *   405 {"error":"Method not allowed"}
 *   413 {"error":"Request too large"}
 *   429 {"error":"Too many report requests — try again later"}
 *   503 {"error":"email_not_configured"} SMTP settings missing (site shows its fallback)
 *   500 {"error":"send_failed"}
 *
 * Request JSON (sent by AssessmentResults.jsx): name, email, company, sector,
 * orgSize, department, consent, assessment, headline, pdfBase64, pdfFilename,
 * website (honeypot), emailHtml + emailHtmlFilename (ignored, as in Node).
 *
 * Nothing is written to a database: like the Node API, a submission exists only
 * as the two emails.
 */

namespace RadiantAssessment;

final class ReportEndpoint
{
    const MAX_BODY_BYTES = 4194304;      // express.json({ limit: '4mb' })
    const MAX_PDF_BASE64 = 5000000;      // same cap as Node

    /** @var array */
    private $cfg;

    public function __construct(array $cfg)
    {
        $this->cfg = $cfg;
    }

    public function handle(): void
    {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');

        if (!$this->applyCors()) {
            $this->respond(403, ['error' => 'CORS blocked']);
            return;
        }
        $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
        if ($method === 'OPTIONS') {
            http_response_code(204);
            return;
        }
        if ($method !== 'POST') {
            header('Allow: POST, OPTIONS');
            $this->respond(405, ['error' => 'Method not allowed']);
            return;
        }

        $limiter = new RateLimiter($this->cfg['RATE_LIMIT_DIR'], 10, 3600);
        if (!$limiter->hit($this->clientIp())) {
            $this->respond(429, ['error' => 'Too many report requests — try again later']);
            return;
        }

        $len = isset($_SERVER['CONTENT_LENGTH']) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
        if ($len > self::MAX_BODY_BYTES) {
            $this->respond(413, ['error' => 'Request too large']);
            return;
        }
        $raw = file_get_contents('php://input', false, null, 0, self::MAX_BODY_BYTES + 1);
        if ($raw === false || strlen($raw) > self::MAX_BODY_BYTES) {
            $this->respond(413, ['error' => 'Request too large']);
            return;
        }
        $body = json_decode($raw, true);
        if (!is_array($body)) {
            $body = [];
        }

        // Honeypot: silently accept bot submissions without sending anything
        if (!empty($body['website'])) {
            $this->respond(200, ['ok' => true]);
            return;
        }

        $email = isset($body['email']) && is_string($body['email']) ? trim($body['email']) : '';
        if ($email === '' || !preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $email)) {
            $this->respond(400, ['error' => 'A valid email is required']);
            return;
        }

        $pdfB64 = isset($body['pdfBase64']) && is_string($body['pdfBase64']) ? $body['pdfBase64'] : '';
        $pdfBytes = ($pdfB64 !== '' && strlen($pdfB64) <= self::MAX_PDF_BASE64) ? base64_decode($pdfB64, true) : false;
        if ($pdfBytes === false || strncmp($pdfBytes, '%PDF', 4) !== 0) {
            $this->respond(400, ['error' => 'A valid report attachment is required']);
            return;
        }

        $mailer = new ReportMailer($this->cfg);
        if (!$mailer->isConfigured()) {
            $this->respond(503, ['error' => 'email_not_configured']);
            return;
        }

        $lead = [
            'name'       => self::str($body, 'name', 120),
            'email'      => mb_substr($email, 0, 160, 'UTF-8'),
            'company'    => self::str($body, 'company', 160),
            'sector'     => self::str($body, 'sector', 80),
            'orgSize'    => self::str($body, 'orgSize', 40),
            'department' => self::str($body, 'department', 80),
            'consent'    => !empty($body['consent']),
            'assessment' => self::str($body, 'assessment', 60),
            'headline'   => self::str($body, 'headline', 200),
        ];
        if ($lead['assessment'] === '') {
            $lead['assessment'] = 'Assessment';
        }
        // frontend sends pdfFilename; keep filename as fallback (as in Node)
        $filename = self::str($body, 'pdfFilename', 120);
        if ($filename === '') {
            $filename = self::str($body, 'filename', 120);
        }
        if ($filename === '') {
            $filename = 'Radiant-Report.pdf';
        }

        try {
            $mailer->sendReport($lead, $pdfBytes, $filename);
            error_log(sprintf('[radiant-assessment] report emailed (%s)', $lead['assessment']));
            $this->respond(200, ['ok' => true]);
        } catch (\Throwable $e) {
            error_log('[radiant-assessment] Report email failed: ' . $e->getMessage());
            $this->respond(500, ['error' => 'send_failed']);
        }
    }

    private static function str(array $body, string $key, int $max): string
    {
        if (!isset($body[$key]) || is_array($body[$key]) || is_object($body[$key])) {
            return '';
        }
        return mb_substr((string) $body[$key], 0, $max, 'UTF-8');
    }

    private function clientIp(): string
    {
        // Same as the Node API (no trust-proxy): the socket peer address.
        // Behind Cloudflare/a load balancer, see README section "Rate limiting".
        $h = $this->cfg['CLIENT_IP_HEADER'];
        if ($h !== '') {
            $key = 'HTTP_' . strtoupper(str_replace('-', '_', $h));
            if (!empty($_SERVER[$key])) {
                return trim(explode(',', $_SERVER[$key])[0]);
            }
        }
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
    }

    /**
     * Same policy as the Node API: allow requests without Origin, same-origin
     * requests, http://localhost:<port>, and FRONTEND_URL. Returns false to block.
     */
    private function applyCors(): bool
    {
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
        if ($origin === '') {
            return true;
        }
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
        $parts = parse_url($origin);
        $originHost = ($parts && isset($parts['host'])) ? $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '') : '';
        $allowed = ($originHost !== '' && $originHost === $host)
            || preg_match('#^http://localhost:\d+$#', $origin)
            || ($this->cfg['FRONTEND_URL'] !== '' && $origin === $this->cfg['FRONTEND_URL']);
        if (!$allowed) {
            return false;
        }
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        header('Vary: Origin');
        return true;
    }

    private function respond(int $status, array $payload): void
    {
        http_response_code($status);
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    }
}
