<?php
/**
 * Email bodies. Markup copied from respondentHtml() / teamHtml() in
 * outputs/radiant-chat-api/utils/mailer.js so both backends send the same email.
 */

namespace RadiantAssessment;

final class Templates
{
    private static function esc($s): string
    {
        return htmlspecialchars((string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function respondentHtml(array $lead): string
    {
        $name = self::esc($lead['name'] !== '' ? $lead['name'] : 'there');
        $assessment = self::esc($lead['assessment']);
        $headline = self::esc($lead['headline']);
        return <<<HTML

  <div style="font-family:Arial,Helvetica,sans-serif;background:#010f1e;color:#e8eef5;padding:32px;border-radius:16px;max-width:560px;margin:auto">
    <div style="font-weight:800;font-size:18px;margin-bottom:18px">RADIANT <span style="color:#91C46B">AI</span></div>
    <h2 style="margin:0 0 12px;font-size:22px;color:#fff">Your {$assessment} report</h2>
    <p style="line-height:1.7;color:#aebacb;margin:0 0 14px">
      Hi {$name}, thanks for completing the {$assessment} assessment.
      {$headline} Your full report is attached as a PDF.
    </p>
    <p style="line-height:1.7;color:#aebacb;margin:0 0 14px">
      It covers your maturity, a breakdown by dimension, your strengths and gaps, and a recommended next step.
      If you'd like to talk it through, just reply to this email.
    </p>
    <p style="color:#8899aa;font-size:12px;margin-top:24px">Radiant Digital · hello@radiant.digital · radiant.digital</p>
  </div>
HTML;
    }

    public static function teamHtml(array $lead): string
    {
        $row = function ($k, $v) {
            $v = ($v === '' || $v === null) ? '—' : $v;
            return '<tr><td style="padding:4px 12px 4px 0;color:#888;font-size:13px">' . self::esc($k)
                . '</td><td style="padding:4px 0;font-size:13px"><b>' . self::esc($v) . '</b></td></tr>';
        };
        $rows = $row('Assessment', $lead['assessment'])
            . $row('Result', $lead['headline'])
            . $row('Name', $lead['name'])
            . $row('Work email', $lead['email'])
            . $row('Company', $lead['company'])
            . $row('Sector', $lead['sector'])
            . $row('Org size', $lead['orgSize'])
            . $row('Department', $lead['department'])
            . $row('Consent to contact', $lead['consent'] ? 'Yes' : 'No');
        return <<<HTML

  <div style="font-family:Arial,Helvetica,sans-serif">
    <h3>New assessment report request</h3>
    <table>
      {$rows}
    </table>
    <p style="color:#888;font-size:12px">The same PDF was emailed to the respondent.</p>
  </div>
HTML;
    }
}
