<?php
/**
 * Sends the assessment report PDF to the respondent and notifies the Radiant
 * team. PHP port of sendReportEmail() in outputs/radiant-chat-api/utils/mailer.js.
 *
 * Behaviour kept identical to the Node version:
 *  - Routed assessments ("AI Maturity", "CX Maturity"): respondent email
 *    (To: respondent, BCC: routing.respondentBcc), then the team email
 *    (To: routing.teamTo, CC: routing.teamCc). Both carry the PDF.
 *  - Any other assessment name: legacy env-driven behaviour (BCC MAIL_CC on the
 *    respondent email; team email to REPORT_NOTIFY_EMAIL, CC MAIL_CC, if set).
 *  - A failure on the respondent email is an error (caller returns 500).
 *    A failure on the team email is logged only.
 */

namespace RadiantAssessment;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as MailException;

final class ReportMailer
{
    /** @var array */
    private $cfg;

    public function __construct(array $cfg)
    {
        $this->cfg = $cfg;
    }

    public function isConfigured(): bool
    {
        // Same rule as isMailConfigured() in mailer.js
        return $this->cfg['SMTP_HOST'] !== '' && $this->cfg['SMTP_USER'] !== ''
            && $this->cfg['SMTP_PASS'] !== '' && $this->cfg['MAIL_FROM'] !== '';
    }

    /**
     * @param array  $lead     name, email, company, sector, orgSize, department, consent, assessment, headline
     * @param string $pdfBytes raw PDF bytes
     * @param string $filename attachment filename
     * @throws MailException when the respondent email cannot be sent
     */
    public function sendReport(array $lead, string $pdfBytes, string $filename): void
    {
        $filename = $filename !== '' ? $filename : 'Radiant-Report.pdf';
        $routing = ReportRouting::forAssessment($lead['assessment']);
        $respondentSubject = 'Your ' . $lead['assessment'] . ' report from Radiant Digital';
        $teamSubject = 'New ' . $lead['assessment'] . ' lead — ' . ($lead['name'] !== '' ? $lead['name'] : $lead['email']);

        if ($routing !== null) {
            $this->send([$lead['email']], [], $routing['respondentBcc'], $respondentSubject,
                Templates::respondentHtml($lead), $pdfBytes, $filename);
            try {
                $this->send($routing['teamTo'], $routing['teamCc'], [], $teamSubject,
                    Templates::teamHtml($lead), $pdfBytes, $filename);
            } catch (\Throwable $e) {
                error_log('[radiant-assessment] Team notification failed: ' . $e->getMessage());
            }
            return;
        }

        // Legacy path (unrouted assessment names), mirrors mailer.js
        $teamCc = $this->teamCc();
        $this->send([$lead['email']], [], $teamCc, $respondentSubject,
            Templates::respondentHtml($lead), $pdfBytes, $filename);
        if ($this->cfg['REPORT_NOTIFY_EMAIL'] !== '') {
            try {
                $this->send([$this->cfg['REPORT_NOTIFY_EMAIL']], $teamCc, [], $teamSubject,
                    Templates::teamHtml($lead), $pdfBytes, $filename);
            } catch (\Throwable $e) {
                error_log('[radiant-assessment] Team notification failed: ' . $e->getMessage());
            }
        }
    }

    /** MAIL_CC from config, else the same default list as mailer.js */
    private function teamCc(): array
    {
        $raw = $this->cfg['MAIL_CC'] !== ''
            ? $this->cfg['MAIL_CC']
            : 'lam.huynh@radiant.digital, alek.nedelkovski@radiant.digital, vinod.mourya@radiant.digital, hello@radiant.digital';
        return array_values(array_filter(array_map('trim', explode(',', $raw))));
    }

    private function send(array $to, array $cc, array $bcc, string $subject, string $html, string $pdfBytes, string $filename): void
    {
        $m = new PHPMailer(true);
        $m->CharSet = PHPMailer::CHARSET_UTF8;
        $m->isSMTP();
        $m->Host = $this->cfg['SMTP_HOST'];
        $m->Port = (int) $this->cfg['SMTP_PORT'];
        $m->SMTPAuth = true;
        $m->Username = $this->cfg['SMTP_USER'];
        $m->Password = $this->cfg['SMTP_PASS'];
        $m->Timeout = 20;

        switch ($this->cfg['encryption']) {
            case 'ssl':        // implicit TLS (port 465) == SMTP_SECURE=true in Node
                $m->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                break;
            case 'none':       // local relay / QA only
                $m->SMTPSecure = '';
                $m->SMTPAutoTLS = false;
                break;
            default:           // 'starttls' (port 587, e.g. Office 365) == Node requireTLS
                $m->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        }

        $from = PHPMailer::parseAddresses($this->cfg['MAIL_FROM'], true, PHPMailer::CHARSET_UTF8);
        if (!$from) {
            throw new MailException('MAIL_FROM is not a valid address');
        }
        $m->setFrom($from[0]['address'], $from[0]['name']);

        foreach ($to as $a)  { $m->addAddress($a); }
        foreach ($cc as $a)  { $m->addCC($a); }
        foreach ($bcc as $a) { $m->addBCC($a); }

        $m->isHTML(true);
        $m->Subject = self::oneLine($subject);
        $m->Body = $html;
        $m->addStringAttachment($pdfBytes, self::oneLine($filename), PHPMailer::ENCODING_BASE64, 'application/pdf');
        $m->send();
    }

    /** Strip CR/LF so user-supplied text can never inject headers */
    private static function oneLine(string $s): string
    {
        return trim(preg_replace('/[\r\n]+/', ' ', $s));
    }
}
