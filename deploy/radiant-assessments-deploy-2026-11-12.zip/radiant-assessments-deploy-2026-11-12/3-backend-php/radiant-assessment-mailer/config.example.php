<?php
/**
 * Copy to config.php (same folder, OUTSIDE the web root) and fill in, or leave
 * config.php absent and provide the same names as environment variables.
 * chmod 640 config.php, owned by the deploy user, group = web server user.
 * NEVER commit config.php.
 *
 * Names match the Node API's .env, so the values already in production
 * (outputs/radiant-chat-api/.env on the server) can be copied across.
 */
return [
    // ── SMTP (required; if any of these 4 is empty the endpoint returns 503) ──
    'SMTP_HOST' => '<SMTP host, e.g. the value already used by the Node API>',
    'SMTP_USER' => '<SMTP username>',
    'SMTP_PASS' => '<SMTP password or app password>',
    'MAIL_FROM' => '<From address, e.g. "Radiant AI <connect@radiant.digital>": confirm with the business>',

    'SMTP_PORT'   => '587',
    'SMTP_SECURE' => 'false',      // "true" only for implicit TLS on port 465
    // 'SMTP_ENCRYPTION' => 'starttls', // optional override: starttls | ssl | none (none = local relay only)

    // ── Optional ─────────────────────────────────────────────────────────────
    // Only used for assessment names WITHOUT fixed routing. The AI and CX
    // assessments ignore these (their recipients are fixed in src/ReportRouting.php).
    'MAIL_CC'             => '',
    'REPORT_NOTIFY_EMAIL' => '',

    // Only needed if the website is served from a DIFFERENT origin than this endpoint.
    'FRONTEND_URL' => '',

    // Writable by the web server user, outside the web root.
    'RATE_LIMIT_DIR' => '/var/lib/radiant-assessment-mailer/ratelimit',

    // Behind Cloudflare/a proxy set e.g. 'CF-Connecting-IP' or 'X-Forwarded-For'
    // ONLY if the origin accepts traffic exclusively from that proxy.
    'CLIENT_IP_HEADER' => '',
];
