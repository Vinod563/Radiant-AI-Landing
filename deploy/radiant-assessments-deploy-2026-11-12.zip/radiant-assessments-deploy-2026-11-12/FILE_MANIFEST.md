# File manifest: what to add, replace or modify on the server

## Website (static files): **replace**
| Package path | Server action |
|---|---|
| `1-frontend/dist/index.html` | **Replace** the app's `index.html` |
| `1-frontend/dist/assets/*` | **Add** (new content-hashed names). Keep the old `assets/` files for ~1 week, then delete them. |
| `1-frontend/dist/images, logos, screenshots, favicon.svg, cio-100-awards.png, hero-bg.mp4` | Same as currently live (unchanged since Aug 12). Overwriting is harmless. |
| `1-frontend/apache/htaccess.reference` | **Merge** into the existing `.htaccess` / vhost **only if missing**. Never overwrite. |

## Email backend: choose ONE option
| Option | Package path | Server action |
|---|---|---|
| A (Node) | `2-backend-node/radiant-chat-api/utils/mailer.js` | **Replace** (back up first), then restart Node. `.env` is untouched. |
| B (PHP) | `3-backend-php/radiant-assessment-mailer/` (whole folder) | **Add** outside the web root, run `composer install --no-dev` |
| B (PHP) | `…/config.example.php` → `config.php` | **Add** on the server with real values. Never commit it. |
| B (PHP) | `3-backend-php/webroot/api/assessment-report.php` | **Add** to the web root at `api/assessment-report.php` |
| B (PHP) | rewrite line in `htaccess.reference` (Option B) | **Modify** (merge) the Apache config |

## Database
None. See `5-database/README.md`.

## Not to be deployed
| Path | Why |
|---|---|
| `4-source/` | Source diff and full changed files, for code review and rebuilding |
| `6-qa/` | Our test evidence and test scripts |
| The server's `radiant-chat-api/.env`, `config.json`, other handlers | Leave as they are |

## Source files changed in this release (from `4-source/changed-files.txt`)
All under `outputs/ai-landing-v1/` unless noted. A = added, M = modified.

| | File | Area |
|---|---|---|
| M | `index.html` | og/twitter title |
| M | `tailwind.config.js` | colour tokens (assessment palette) |
| M | `src/main.jsx` | imports `theme.css` |
| A | `src/styles/theme.css`, `src/theme/tokens.js` | assessment palette |
| A | `src/components/assessment/AssessmentHeader.jsx` | minimal assessment header |
| M | `src/components/assessment/{AssessmentLeadForm, AssessmentQuestionCard, AssessmentResults, Dropdown, GartnerPositioningView, HTMLReportViewer, LockedReport, ProfileForm, QuestionRunner, ResultsContact, ScoreBars, StageReveal, WhatAILeadersDo}.jsx` | AI + CX flow, a11y, readability |
| M | `src/data/cxAssessment.js` | CX questions, answers, scoring |
| A | `src/data/cxReportEditorial.js` | CX report copy |
| M | `src/data/assessmentContent.js` | CX card copy (hub + homepage) |
| M | `src/data/knowledgeBase.js` | chat CX answers only (4 entries) |
| M | `src/pages/{AiAssessment, CxAssessment, AssessmentHub}.jsx` | flow, save/resume, titles |
| M | `src/pages/Chat.jsx` | in-chat CX flow (role-tailored), h2 heading |
| M | `src/pages/Index.jsx` | `/#assessment` scroll on arrival |
| M | `src/components/home/PersonaPaths.jsx` | "Lead With Experience" card |
| M | `src/components/shared/Navbar.jsx` | header CTA |
| M | `src/components/shared/SectionNav.jsx` | mobile CTA scroll fix |
| M | `src/components/shared/Footer.jsx` | accessible names only |
| M | `src/utils/{aiExecutiveReport, aiReportPdf, emailSafeReport, generateReportPdf}.js(x)` | AI report title, shared report pipeline |
| A | `src/utils/{cxReportPdf.jsx, assessmentProgress.js}` | CX PDF, saved progress |
| M | `outputs/radiant-chat-api/utils/mailer.js` | email routing |
