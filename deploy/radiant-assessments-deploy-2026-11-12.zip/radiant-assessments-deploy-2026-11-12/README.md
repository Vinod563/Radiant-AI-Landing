# Radiant AI: AI & CX Assessment release (2026-11-12)

This package does four things:

- Launches the **new CX Maturity Assessment**.
- Ships the **latest AI Maturity Assessment** updates.
- Updates the **homepage hero** (the "Lead With Experience" card and the "Assess Your AI and CX Readiness" header CTA).
- Applies the **new email recipient routing** for both assessments.

It contains no unrelated redesign work. See "What is deliberately NOT in this release".

| Read next | |
|---|---|
| `CHANGE_SUMMARY.md` | Everything that changed since the last deployment |
| `FILE_MANIFEST.md` | Every file to add or replace on the server |
| `DEPLOYMENT_CHECKLIST.md` | Pre-deploy, deploy, and go-live verification |
| `6-qa/` | Automated test results and screenshots from our run |

---

## 1. Read this first: how this app is actually built

**The assessments are not PHP pages.** They are part of the Radiant AI site, a **React single-page app** (Vite build) that is compiled to static files (`1-frontend/dist`). It has two parts:

| Part | Technology | Runs on Apache/PHP? |
|---|---|---|
| Website, both assessments, scoring, PDF report generation | Static HTML/JS/CSS (built React) | **Yes.** Apache serves these as plain files, with one rewrite rule (section 4). |
| `POST /api/assessment-report` (emails the PDF) | **Node.js 18+** Express API (`radiant-chat-api`) using Nodemailer/SMTP | **No.** It needs Node, *or* the PHP replacement in `3-backend-php`. |
| `POST /api/chat`, `POST /api/contact` (chat assistant, contact form) | Same Node API | **No.** Unchanged by this release, still needs Node. |

The scoring and the PDF are produced **in the visitor's browser**. The server only receives the finished PDF and emails it. No database is involved (see `5-database/README.md`).

**Where the site runs.** The main `radiant.digital` site is a different (Apache/PHP) site. The React app was not reachable at `radiant.digital/assessment/...` when we checked on 2026-11-12. The deployment team must confirm which host or path serves this app today, and how `/api/*` reaches the Node API there (section 7, item 1).

## 2. Release baseline

"Last deployment" = commit **`614ad16`** (2026-08-12, branch `ai-test-integration`). Evidence: it is the deployer's last commit, and the Node API's `.env` backup on the build machine is timestamped 2026-08-12 14:53. **Please confirm against what is live** (section 7, item 2).

This release = `614ad16` + the assessment/hero/email changes from `bd72760` (branch `leadership-imagery`) + one bug fix (CHANGE_SUMMARY §E). The full source diff is `4-source/release-vs-2026-08-12-baseline.patch`.

## 3. Choose how the report email is sent (Option A or B)

### Option A (recommended if the Node API is already running in production)
This is a one-file change; nothing else on the server changes.
1. Back up `radiant-chat-api/utils/mailer.js` on the server.
2. Replace it with `2-backend-node/radiant-chat-api/utils/mailer.js`.
3. Restart the Node process (e.g. `pm2 restart <name>` / `systemctl restart <unit>`; use whatever runs it today).
4. **Do not touch the server's `.env`.** It keeps working. The AI and CX recipients are now fixed in code and ignore `MAIL_CC` / `REPORT_NOTIFY_EMAIL` (those still apply to the contact form).

### Option B (only if Node is NOT available for the report email)
`3-backend-php/` is a PHP port of the same endpoint: same URL, request, validation, rate limit (10 per hour per IP), responses, email bodies, subjects and recipients. The website needs no change.

Requirements: **PHP 7.4+** with `json`, `mbstring`, `openssl`; **Composer**; outbound SMTP (port 587 STARTTLS, or 465).
1. Copy `3-backend-php/radiant-assessment-mailer/` **outside** the web root, e.g. `/var/www/radiant-assessment-mailer`.
2. Run `composer install --no-dev` in it (installs PHPMailer 6.9+).
3. `cp config.example.php config.php`, then fill in the SMTP values (reuse the Node `.env` values) and `chmod 640`. Alternatively, supply the same names as Apache `SetEnv` / environment variables.
4. Create `RATE_LIMIT_DIR`, writable by the web-server user.
5. Copy `3-backend-php/webroot/api/assessment-report.php` into the site's web root at `api/assessment-report.php`. If the app folder isn't at `/var/www/radiant-assessment-mailer`, edit `$appDir` in that file.
6. Enable the Option B rewrite line in `1-frontend/apache/htaccess.reference` (merge it into the existing config).
7. `/api/chat` and `/api/contact` still need the Node API. Without it the chat assistant and contact form won't work (as before this release).

> ⚠️ **The PHP port has been code-reviewed but NOT executed.** No PHP runtime was available on the build machine. Run checklist section C on staging before go-live. Option A was tested end to end.

## 4. Deploy the website files

1. **Back up** the current web root of the React app (`index.html` + `assets/` + everything else).
2. Upload **the whole contents** of `1-frontend/dist/` to that web root.
   - It's a compiled bundle; individual files can't be cherry-picked. `index.html` must be replaced.
   - **Keep the old `assets/*.js|css` files for ~1 week** (upload alongside, don't delete). Visitors with the old page open still lazy-load old chunks. Remove them afterwards.
   - `dist` contains no `.htaccess`, so it won't overwrite server config.
3. Make sure Apache has the SPA fallback and the `/api` routing (`1-frontend/apache/htaccess.reference`). **Merge it; don't overwrite.** The existing server config may already contain this.
4. The build calls the API **same-origin** (`/api/assessment-report`). If production serves the API from another domain, rebuild with `VITE_CHAT_API_URL=https://api-host` (section 6) and set `FRONTEND_URL` on the API side for CORS.

## 5. Verify
Work through `DEPLOYMENT_CHECKLIST.md` (staging first, then production). Pay particular attention to the email routing checks. They send real emails to the listed Radiant addresses, so tell those people a test is coming.

## 6. Rebuilding from source (optional)
The `dist` here was built from `614ad16` + `4-source/release-vs-2026-08-12-baseline.patch`, with Node 26 and the repo's `package-lock.json` (dependencies unchanged since `614ad16`):
```bash
git checkout 614ad16
git apply release-vs-2026-08-12-baseline.patch
cd outputs/ai-landing-v1 && npm ci && npm run build   # -> dist/
```
`4-source/changed-files/` holds the full text of every changed source file, for review.

## 7. Must be confirmed by the deployment team / business (not guessed)

1. **Hosting topology.** Which host or path serves this React app, and how `/api/*` reaches the Node API (reverse proxy? port?). This decides Option A vs B.
2. **Baseline.** That production currently runs commit `614ad16` (Aug 12). If production is older, CHANGE_SUMMARY still applies, but re-check the homepage after deploy. If it's *newer* (for example the Leadership section is already live), **stop**: deploying this build would remove it. Contact the project owner.
3. **SMTP credentials and From address.** Use the existing production values. The project log records the sender as `connect@radiant.digital`. Confirm that mailbox is allowed to send as itself via the SMTP account, and that BCC/CC to 4–6 recipients is allowed.
4. **Recipient mailboxes exist.** These are taken from code as approved on 2026-11-12; we couldn't check that they exist: `lam.huynh@`, `alek.nedelkovski@`, `vinod.mourya@`, `elizabeth.holland@`, `tushar.hande@`, `deena.bhattacharjee@`, `connect@`, `hello@` (all `@radiant.digital`).
5. **Third-party tags.** The page loads Google Tag Manager `GTM-KNXCSW5Q` (unchanged). One tag in it (Apollo intent pixel) rejects non-production domains with HTTP 400. That's harmless, but expect it in staging browser consoles.
6. **Rate limiting behind a proxy/CDN.** Both backends limit by the connecting IP. Behind Cloudflare or a load balancer, all visitors may share one IP: 10 reports per hour site-wide. For Node, enable Express `trust proxy`; for PHP, set `CLIENT_IP_HEADER`. Only do this if the origin accepts traffic solely from that proxy.

## What is deliberately NOT in this release
Work on the same branch that is unrelated to the assessments was left out (it remains in git):
- Leadership portrait section, its nav link and dot, its CSS, and 13 portrait images.
- The "Governing Unstructured and Structured Data" case study, case-study layout/table-of-contents changes, and the contact-card heading change, plus the matching chat-API knowledge files (`knowledge/radiantContext.js`, `handlers/staticHandler.js`, `utils/cardBuilder.js`).
- The Light/Dark theme (parked on branch `theme-light-dark`).
- `outputs/ai-assessment-executive-pdf/index.html` (a standalone design mock with Prafull Khare's updated title). It isn't part of the deployed site; the live PDF title change *is* included via `aiReportPdf.jsx`.
