# Deployment checklist

Run sections C–G on **staging first**, then repeat C–G on production right after go-live.
✅ = verified by us on the build machine (Node option, local test SMTP server, 2026-11-12). Evidence is in `6-qa/`. These still need checking on your servers.

## A. Before deploying
- [ ] README §7 items confirmed: hosting topology, baseline `614ad16`, SMTP and sender, recipient mailboxes, proxy/IP
- [ ] Option chosen: **A (Node)** / **B (PHP)**
- [ ] Backups taken: current web root (all files), `radiant-chat-api/utils/mailer.js`, Apache config
- [ ] Recipients told that test emails are coming (both lists in CHANGE_SUMMARY §F)
- [ ] Code review of `4-source/release-vs-2026-08-12-baseline.patch` done

## B. Deploy
- [ ] `dist/` uploaded; `index.html` replaced; old `assets/` kept
- [ ] Apache SPA fallback present (`/assessment/cx` loads the app, not a 404)
- [ ] `/api/assessment-report` routed to Node (A) or PHP (B)
- [ ] Option A: `mailer.js` replaced, Node restarted, process healthy (`GET /` on the API returns `{"status":"ok"}`)
- [ ] Option B: `composer install` done, `config.php` filled and `chmod 640`, rate-limit dir writable
- [ ] Browser cache bypassed for testing (hard refresh / private window)

## C. Report endpoint (quick server-side checks)
- [ ] `curl -X POST https://<site>/api/assessment-report -H 'Content-Type: application/json' -d '{"email":"bad"}'` returns **400** `{"error":"A valid email is required"}` (proves routing reaches the backend, not `index.html`)
- [ ] Same with `{"email":"a@b.co"}` returns **400** `{"error":"A valid report attachment is required"}`
- [ ] `GET /api/assessment-report` returns an error (404/405), **not** the website HTML
- [ ] Option B only: no PHP errors in the Apache/PHP error log

## D. Homepage hero and navigation (desktop 1920, tablet 768, mobile 375)
- [ ] ✅ Three hero cards; the third is **"Lead With Experience"** with "Find the friction. Fix the journey." and CTA "See how your CX measures up"
- [ ] ✅ Clicking that card opens `/assessment/cx` at the profile step
- [ ] ✅ Header CTA reads **"Assess Your AI and CX Readiness"** and scrolls to "Where does your enterprise stand?"
- [ ] ✅ Mobile: menu → CTA scrolls to the same section (the fix in CHANGE_SUMMARY §E)
- [ ] ✅ From `/assessment` (or any other page) the CTA goes to `/#assessment` and scrolls there
- [ ] ✅ Assessment section shows both cards; the CX card reads "A role-adaptive diagnostic… 10-12 min"
- [ ] ✅ No horizontal scrolling at 768 / 375
- [ ] ✅ Rest of the homepage unchanged (no Leadership section, no new nav items)

## E. CX Maturity Assessment
- [ ] ✅ `/assessment/cx` tab title "CX Maturity Assessment | Radiant AI"; minimal header with "Exit"
- [ ] ✅ Role is required; Executive and Practitioner each give **12 questions**, 5 options each
- [ ] ✅ Next disabled until an answer is selected; "Why this matters" sits below the options
- [ ] Wording spot-check: Executive Q2 option 2 reads "Leaders in service, marketing, IT, or other teams handle it informally."; no "board / ROI / compensation / marketing budgets" in the answers
- [ ] Save and exit mid-way → reopen `/assessment/cx` → "Welcome back… Start over" resumes at the same question
- [ ] ✅ Results: stage (1–5, Reactive → Embedded), dimension scores, findings, next step
- [ ] ✅ "Get full report" → form pre-filled from the profile → submit → "Your report is on its way" with the respondent's email shown
- [ ] Chat: "Assess my CX maturity" → CX card → profile asks for the role → questions run in chat

## F. AI Maturity Assessment (regression)
- [ ] ✅ `/assessment/ai` runs 12 questions → results → full report emailed
- [ ] PDF contact card shows "Prafull Khare, Vice President - Global Head of AI & Digital Transformation"
- [ ] Results and stages look as they did before deployment for the same answers (spot-check one known answer set)

## G. Email notifications (real mailboxes)
Submit one AI and one CX report using a test inbox you control.
- [ ] ✅ **CX respondent email:** To = test inbox; subject "Your CX Maturity report from Radiant Digital"; PDF attached; From = production `MAIL_FROM`; BCC addresses **not visible** to the respondent
- [ ] **CX BCC received** by lam.huynh and elizabeth.holland
- [ ] ✅ **CX team email** "New CX Maturity lead — <name>": To connect@ + hello@; CC lam.huynh, elizabeth.holland, tushar.hande, deena.bhattacharjee; lead details + PDF
- [ ] **AI respondent email:** BCC received by lam.huynh, alek.nedelkovski, vinod.mourya
- [ ] ✅ **AI team email** "New AI Maturity lead — <name>": To connect@ + hello@; CC lam.huynh, alek.nedelkovski, vinod.mourya
- [ ] The CX submission did **not** reach AI-only recipients (alek, vinod), and the AI submission did not reach CX-only recipients (elizabeth, tushar, deena)
- [ ] Emails didn't land in spam (check the SPF/DKIM pass in the message headers)
- [ ] Failure path: with SMTP temporarily misconfigured on **staging**, the page shows "Thanks, we have your details" instead of "Your report is on its way" (API returns 503/500), and the respondent is not left on a spinner

## H. Accessibility (both assessments)
- [ ] ✅ axe-core WCAG 2.1 AA: 0 violations on profile, question, results and report form (AI and CX) and on the hub
- [ ] Keyboard only: Tab through role choice, answers (arrow/Space/Enter), Next/Back, report form, and modal close; the focus ring is visible
- [ ] Screen reader (VoiceOver/NVDA): announces "Question N of 12" and the progress value
- Note: the **homepage** has pre-existing axe findings (button-name, color-contrast, scrollable-region-focusable, svg-img-alt). They're identical on the Aug 12 build and outside this release's scope. This release removes the `link-name` findings.

## I. Go/no-go and rollback
- [ ] All the above pass on production → go
- **Rollback (website):** restore the backed-up web root (`index.html` + `assets/`).
- **Rollback (email):** Option A: restore the old `mailer.js` and restart Node. Option B: remove the rewrite line (`api/assessment-report.php` is then unused).
- Nothing in the database to roll back.
