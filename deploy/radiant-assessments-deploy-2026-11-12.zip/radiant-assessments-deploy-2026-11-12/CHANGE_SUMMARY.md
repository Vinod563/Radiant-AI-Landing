# Change summary: since the last deployment (`614ad16`, 2026-08-12)

Sources: the git history and `logs/PROJECT_LOG.md` entries dated 2026-10-26 to 2026-11-12.

## A. CX Maturity Assessment (new on the live site)
The CX assessment that existed at `614ad16` was a short 9-question, 3-level prototype. It has been **rebuilt** to match the AI assessment.

- **Structure:** two role tracks (Executive: C-suite/VP/Director; Practitioner: CX, Research, Design, Service Ops) with **12 questions each**. Four questions are shared, giving 20 distinct questions and 100 answer options on a 1–5 scale.
- **Dimensions:** Strategy & Leadership, Insight & Understanding, Design & Delivery, Culture & Accountability.
- **Scoring:** 5-stage ladder (Reactive → Embedded) with per-dimension averages. The results show findings, a recommended next step, positioning (Strategic Maturity vs Execution Readiness), and a "What CX leaders do" panel.
- **Full report:** a 9-section executive-briefing PDF (`cxReportPdf.jsx`, editorial copy in `cxReportEditorial.js`), emailed on request.
- **Content updates:**
  - Question stems rewritten for clarity, average length cut from ~19 to 12.8 words (11-05).
  - All 100 answer options shortened and made **sector-neutral**, e.g. board → senior leadership, ROI → outcome targets, marketing budgets → program/operations budgets (11-06), followed by 5 QA fixes (11-06).
  - Q2 (Executive) option 2 broadened to "Leaders in service, marketing, IT, or other teams handle it informally." (11-11).
- **Entry points:**
  - `/assessment/cx`.
  - The assessment hub `/assessment`.
  - The homepage assessment section, where the card now reads "role-adaptive … 10-12 min".
  - The chat ("Assess my CX maturity"), which now uses the role-tailored profile and the new description.
  - The new hero card (C).

## B. AI Maturity Assessment (updates)
No changes to questions, scoring or stages. Changes:
- **Shared components gained CX support:** they take optional props, with AI defaults, so AI behaviour is unchanged.
- **Prafull Khare's title** in the report contact cards (web report, PDF, email-safe report) is now "Vice President - Global Head of AI & Digital Transformation".

## C. Flow, readability and accessibility (both assessments)
- **Flow:**
  - Next is disabled until an answer is chosen.
  - During the assessment, a minimal header (logo + Exit / "Save and exit") replaces the marketing nav.
  - Progress is saved in the browser, with a "Welcome back… / Start over" option.
  - "Why this matters" now sits below the options.
  - Role choice is required (radio group, clear selected state).
- **Accessibility:**
  - One `h1` per screen.
  - `role="progressbar"` with values.
  - Live region announcing "Question N of 12".
  - Accessible names on the logo and social links.
- **Readability:** dedicated assessment palette (`theme.css`, `tokens.js`); minimum text size 13px; answers at 16px; heading weight 700; headings softened to #D6DEE8; distinct hover, selected and focus states.
- **Tab titles:** "AI/CX Maturity Assessment | Radiant AI". og/twitter titles: "Radiant AI – Enterprise AI Solutions".
- **Measured result:** axe-core WCAG 2.1 AA reports 0 violations on the profile, question, results and report-form screens for both assessments, and on the hub (our run, `6-qa/e2e-results.json`).

## D. Homepage hero and navigation
- **New "Lead With Experience" card** (third persona card, orange): "Find the friction. Fix the journey.", blurb, and CTA "See how your CX measures up". It opens `/assessment/cx` at the profile step. It replaces the old "Focused on customer experience? Take the CX Maturity Assessment" text link. Cards are equal height, 3 columns at ≥1024px and stacked below.
- **Header CTA** "Assess Your AI Readiness" (which linked to `/assessment/ai`) becomes "**Assess Your AI and CX Readiness**". It smooth-scrolls to the homepage assessment section `#assessment`. From any other page it goes to `/#assessment`, and the homepage scrolls on arrival. The same applies in the mobile menu.

## E. Bug fix added while preparing this package
On screens below 1024px, the new header CTA's scroll stopped about 400px down the page and never reached the section. **Cause:** the homepage dot-navigation, which is hidden below 1024px, still mounted once you scrolled. Framer Motion then measured its hidden progress bar and reset the scroll position, cancelling the scroll.
- **Fix:** don't mount the dot-nav below 1024px (`SectionNav.jsx`, one line). There's no visual change, because it was already invisible at those widths.
- **Verified:** the CTA now lands on the section at 375, 1023, 1024 and 1920px wide.
- The same fix was applied, uncommitted, to the working branch: `4-source/working-branch-fix-mobile-cta.patch`.

## F. Assessment email notifications (`radiant-chat-api/utils/mailer.js`)
Recipients are now **fixed in code per assessment**, so `.env` changes can't alter them. The sender is still `MAIL_FROM`.

| Assessment | Respondent's PDF email | Team email "New … lead — [name]" (PDF attached) |
|---|---|---|
| **AI Maturity** | To: respondent · **BCC:** lam.huynh, alek.nedelkovski, vinod.mourya | **To:** connect@, hello@ · **CC:** lam.huynh, alek.nedelkovski, vinod.mourya |
| **CX Maturity** | To: respondent · **BCC:** lam.huynh, elizabeth.holland | **To:** connect@, hello@ · **CC:** lam.huynh, elizabeth.holland, tushar.hande, deena.bhattacharjee |

All addresses are `@radiant.digital`.

- **Before:** both assessments used `MAIL_CC` (BCC on the respondent email) and `REPORT_NOTIFY_EMAIL`. The team email was sent only if `REPORT_NOTIFY_EMAIL` was set.
- **Now:** the team email is always sent for AI and CX. The two flows are independent, keyed by the `assessment` value the page sends ("AI Maturity" / "CX Maturity").
- **Unchanged:** the contact form still uses `MAIL_CC` / `CONTACT_NOTIFY_EMAIL`.
- **Verified end to end:** real browser → Node API → STARTTLS SMTP test sink, for 5 submissions (CX Executive, CX Practitioner, AI Executive, CX mobile, AI tablet). Recipients, BCC kept out of headers, subjects, sender, lead details and PDF attachment all matched (`6-qa/e2e-results.json`).

## Not changed
Questions, scoring and stage logic of the AI assessment; every other homepage section (text diff against the Aug 12 build: `6-qa/home-baseline.txt` vs `home-release.txt`, which differ only in D and A's homepage card); the chat API apart from `mailer.js`; the database (none used).
