"""Minimal SMTP sink for local QA. Never relays anything.

Accepts EHLO/HELO, optional STARTTLS (when a cert is given), AUTH (any creds),
MAIL/RCPT/DATA/RSET/NOOP/QUIT. Each message is written to OUT_DIR as a JSON file
holding the envelope sender, envelope recipients and raw message.

usage: python3 -I smtp_sink.py PORT OUT_DIR [CERT KEY]
"""
import asyncio, json, os, ssl, sys, time

PORT, OUT = int(sys.argv[1]), sys.argv[2]
CERT = sys.argv[3] if len(sys.argv) > 4 else None
KEY = sys.argv[4] if len(sys.argv) > 4 else None
os.makedirs(OUT, exist_ok=True)
counter = 0


async def handle(reader, writer):
    global counter
    tls = False

    async def send(line):
        writer.write((line + "\r\n").encode())
        await writer.drain()

    await send("220 qa-sink ESMTP")
    mail_from, rcpts = None, []
    while True:
        raw = await reader.readline()
        if not raw:
            break
        line = raw.decode(errors="replace").rstrip("\r\n")
        cmd = line.split(" ", 1)[0].upper()
        if cmd in ("EHLO", "HELO"):
            caps = ["250-qa-sink", "250-SIZE 20000000", "250-8BITMIME", "250-AUTH PLAIN LOGIN"]
            if CERT and not tls:
                caps.append("250-STARTTLS")
            caps.append("250 SMTPUTF8")
            for c in caps:
                await send(c)
        elif cmd == "STARTTLS" and CERT and not tls:
            await send("220 Ready to start TLS")
            ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            ctx.load_cert_chain(CERT, KEY)
            if hasattr(writer, "start_tls"):
                await writer.start_tls(ctx)
            else:  # Python < 3.11
                loop = asyncio.get_running_loop()
                tr = writer.transport
                new_tr = await loop.start_tls(tr, tr.get_protocol(), ctx, server_side=True)
                writer._transport = new_tr
                reader._transport = new_tr
            tls = True
        elif cmd == "AUTH":
            parts = line.split()
            if len(parts) >= 2 and parts[1].upper() == "LOGIN":
                await send("334 VXNlcm5hbWU6")
                await reader.readline()
                await send("334 UGFzc3dvcmQ6")
                await reader.readline()
            elif len(parts) == 2:
                await send("334 ")
                await reader.readline()
            await send("235 Authentication successful")
        elif cmd == "MAIL":
            mail_from, rcpts = line[10:].strip(), []
            await send("250 OK")
        elif cmd == "RCPT":
            rcpts.append(line[8:].strip())
            await send("250 OK")
        elif cmd == "DATA":
            await send("354 End data with <CR><LF>.<CR><LF>")
            data = []
            while True:
                l = await reader.readline()
                if l in (b".\r\n", b".\n") or not l:
                    break
                data.append(l.decode(errors="replace"))
            counter += 1
            os.makedirs(OUT, exist_ok=True)
            path = os.path.join(OUT, f"{int(time.time()*1000)}-{counter:03d}.json")
            with open(path, "w") as f:
                json.dump({"from": mail_from, "rcpt": rcpts, "tls": tls, "raw": "".join(data)}, f)
            await send("250 OK queued")
        elif cmd == "RSET":
            mail_from, rcpts = None, []
            await send("250 OK")
        elif cmd == "NOOP":
            await send("250 OK")
        elif cmd == "QUIT":
            await send("221 Bye")
            break
        else:
            await send("502 Command not implemented")
    writer.close()


async def main():
    server = await asyncio.start_server(handle, "127.0.0.1", PORT)
    print(f"smtp sink listening on {PORT} (starttls={'yes' if CERT else 'no'})", flush=True)
    async with server:
        await server.serve_forever()

asyncio.run(main())
