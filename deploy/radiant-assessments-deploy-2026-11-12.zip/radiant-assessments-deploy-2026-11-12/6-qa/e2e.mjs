// End-to-end QA for the assessment release build.
// usage: node e2e.mjs BASE_URL MAIL_DIR SHOT_DIR
import { chromium } from 'playwright'
import fs from 'fs'
import path from 'path'

const [BASE, MAIL_DIR, SHOTS] = process.argv.slice(2)
const AXE = fs.readFileSync(new URL('./node_modules/axe-core/axe.min.js', import.meta.url), 'utf8')
for (const d of ['desktop', 'tablet', 'mobile']) fs.mkdirSync(path.join(SHOTS, d), { recursive: true })
const VIEWPORTS = { desktop: { width: 1920, height: 1080 }, tablet: { width: 768, height: 1024 }, mobile: { width: 375, height: 667 } }

const results = []
const ok = (name, pass, detail = '') => { results.push({ name, pass: !!pass, detail }); console.log(`${pass ? 'PASS' : 'FAIL'}  ${name}${detail ? '  — ' + detail : ''}`) }

const browser = await chromium.launch({ executablePath: process.env.HOME + '/Library/Caches/ms-playwright/chromium_headless_shell-1234/chrome-headless-shell-mac-x64/chrome-headless-shell' })
const errors = []
async function newPage(vp = 'desktop') {
  const ctx = await browser.newContext({ viewport: VIEWPORTS[vp] })
  const page = await ctx.newPage()
  page.on('pageerror', e => errors.push(`pageerror: ${e.message}`))
  page.on('console', m => { if (m.type() === 'error') errors.push(`console: ${m.text()}`) })
  return page
}
const mailFiles = () => fs.existsSync(MAIL_DIR) ? fs.readdirSync(MAIL_DIR).filter(f => f.endsWith('.json')).sort() : []
const header = (raw, name) => {
  const unfolded = raw.replace(/\r?\n[ \t]+/g, ' ')
  const m = unfolded.match(new RegExp(`^${name}:\\s*(.*)$`, 'im'))
  return m ? m[1].trim() : ''
}
// RFC 2047: join adjacent encoded words, decode bytes as UTF-8
const decodeMime = s => s.replace(/\?=\s+=\?/g, '?==?').replace(/=\?utf-8\?([bq])\?([^?]*)\?=/gi, (_, enc, txt) => enc.toLowerCase() === 'b'
  ? Buffer.from(txt, 'base64').toString('utf8')
  : Buffer.from(txt.replace(/_/g, ' ').replace(/=([0-9A-F]{2})/gi, (__, h) => String.fromCharCode(parseInt(h, 16))), 'latin1').toString('utf8'))
// Decode quoted-printable / base64 body parts so content checks see real text
const bodyText = raw => {
  const qp = raw.replace(/=\r?\n/g, '').replace(/=([0-9A-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)))
  const b64 = (raw.match(/Content-Transfer-Encoding: base64\r?\n(?:[^\r\n]+\r?\n)*\r?\n([A-Za-z0-9+/=\r\n]+)/gi) || [])
    .map(part => { try { return Buffer.from(part.split(/\r?\n\r?\n/).pop().replace(/\s+/g, ''), 'base64').toString('latin1') } catch { return '' } }).join('\n')
  return Buffer.from(qp, 'latin1').toString('utf8') + '\n' + b64
}
const addrs = s => (s.match(/[\w.+-]+@[\w.-]+/g) || []).map(a => a.toLowerCase()).sort()
const sameSet = (a, b) => JSON.stringify([...new Set(a)].sort()) === JSON.stringify([...new Set(b)].sort())

async function axe(page, label) {
  await page.addScriptTag({ content: AXE })
  const r = await page.evaluate(async () => {
    const res = await window.axe.run(document, { runOnly: { type: 'tag', values: ['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'] } })
    return res.violations.map(v => `${v.id}(${v.nodes.length})`)
  })
  ok(`axe WCAG 2.1 AA: ${label}`, r.length === 0, r.join(', ') || '0 violations')
}

// ── 1. Homepage: hero CX card, header CTA, no unrelated sections ────────────
{
  const page = await newPage('desktop')
  await page.goto(BASE + '/', { waitUntil: 'networkidle' })
  const cards = await page.locator('button:has(h3)').filter({ hasText: /Lead With Experience|See where you stand|Context Engine|/ }).allInnerTexts()
  const cx = page.locator('button', { has: page.locator('h3', { hasText: 'Lead With Experience' }) })
  ok('Hero: "Lead With Experience" card present', await cx.count() === 1)
  const cxText = (await cx.innerText()).replace(/\s+/g, ' ')
  ok('Hero CX card copy', /Find the friction\. Fix the journey\./.test(cxText) && /strategy, insight, design, and accountability/.test(cxText) && /See how your CX measures up/.test(cxText), cxText)
  ok('Hero: 3 persona cards side by side at desktop', await page.evaluate(() => {
    const h = [...document.querySelectorAll('h3')].find(e => e.textContent.trim() === 'Lead With Experience')
    const grid = h?.closest('.grid'); if (!grid) return false
    const tops = [...grid.children].map(c => Math.round(c.getBoundingClientRect().top))
    return grid.children.length === 3 && new Set(tops).size === 1
  }))
  ok('No Leadership section (#leadership) on homepage', await page.locator('#leadership').count() === 0)
  ok('No "Leadership" link in header nav', await page.locator('header >> text=Leadership').count() === 0 && await page.locator('nav a', { hasText: 'Leadership' }).count() === 0)
  const cta = page.locator('a', { hasText: 'Assess Your AI and CX Readiness' }).first()
  ok('Header CTA reads "Assess Your AI and CX Readiness" and targets /#assessment', await cta.isVisible() && await cta.getAttribute('href') === '/#assessment')
  await cta.click(); await page.waitForTimeout(1500)
  const top = await page.evaluate(() => Math.round(document.getElementById('assessment').getBoundingClientRect().top))
  ok('Header CTA smooth-scrolls to the assessment section on the homepage', Math.abs(top) < 150, `section top=${top}px`)
  const entry = (await page.locator('#assessment').innerText()).replace(/\s+/g, ' ')
  ok('Assessment section lists both AI and CX assessments', /AI Maturity Assessment/i.test(entry) && /CX Maturity Assessment/i.test(entry))
  ok('Assessment section shows updated CX card (new description, 10-12 min)', /10-12 min/.test(entry) && /role-adaptive diagnostic across strategy, insight, design, and accountability/i.test(entry), entry.slice(entry.search(/CX MATURITY/i), entry.search(/CX MATURITY/i) + 300))
  await page.screenshot({ path: path.join(SHOTS, 'desktop', 'home-assessment-section.png') })
  await page.evaluate(() => window.scrollTo(0, 0)); await page.waitForTimeout(600)
  await page.screenshot({ path: path.join(SHOTS, 'desktop', 'home-hero.png') })
  await axe(page, 'homepage')
  await cx.click(); await page.waitForURL('**/assessment/cx'); await page.waitForTimeout(500)
  ok('Hero CX card opens /assessment/cx at the profile step', await page.locator('text=Start the assessment').count() === 1)
  await page.context().close()
}
for (const vp of ['tablet', 'mobile']) {
  const page = await newPage(vp)
  await page.goto(BASE + '/', { waitUntil: 'networkidle' }); await page.waitForTimeout(500)
  await page.screenshot({ path: path.join(SHOTS, vp, 'home-hero.png'), fullPage: false })
  const h = page.locator('h3', { hasText: 'Lead With Experience' })
  await h.scrollIntoViewIfNeeded(); await page.waitForTimeout(400)
  await page.screenshot({ path: path.join(SHOTS, vp, 'home-hero-cx-card.png') })
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth)
  ok(`${vp}: homepage has no horizontal overflow`, overflow <= 0, `overflow=${overflow}px`)
  if (vp === 'mobile') {
    await page.evaluate(() => window.scrollTo(0, 0))
    await page.locator('header button').last().click(); await page.waitForTimeout(400)
    const m = page.locator('a', { hasText: 'Assess Your AI and CX Readiness' }).last()
    ok('mobile: menu shows the AI and CX CTA', await m.isVisible())
    await m.click(); await page.waitForTimeout(1500)
    const top = await page.evaluate(() => Math.round(document.getElementById('assessment').getBoundingClientRect().top))
    ok('mobile: menu CTA scrolls to the assessment section', Math.abs(top) < 150, `top=${top}px`)
  }
  await page.context().close()
}

// ── 2. Full assessment runs (profile → questions → results → email) ─────────
const ROUTING = {
  'AI Maturity': {
    bcc: ['lam.huynh@radiant.digital', 'alek.nedelkovski@radiant.digital', 'vinod.mourya@radiant.digital'],
    teamTo: ['connect@radiant.digital', 'hello@radiant.digital'],
    teamCc: ['lam.huynh@radiant.digital', 'alek.nedelkovski@radiant.digital', 'vinod.mourya@radiant.digital'],
  },
  'CX Maturity': {
    bcc: ['lam.huynh@radiant.digital', 'elizabeth.holland@radiant.digital'],
    teamTo: ['connect@radiant.digital', 'hello@radiant.digital'],
    teamCc: ['lam.huynh@radiant.digital', 'elizabeth.holland@radiant.digital', 'tushar.hande@radiant.digital', 'deena.bhattacharjee@radiant.digital'],
  },
}

async function runAssessment({ kind, roleName, pick, vp = 'desktop', shots = false, a11y = false }) {
  const label = `${kind.toUpperCase()} / ${roleName} / ${vp}`
  const assessment = kind === 'ai' ? 'AI Maturity' : 'CX Maturity'
  const page = await newPage(vp)
  await page.goto(`${BASE}/assessment/${kind}`, { waitUntil: 'networkidle' })
  ok(`${label}: tab title`, (await page.title()) === `${kind === 'ai' ? 'AI' : 'CX'} Maturity Assessment | Radiant AI`, await page.title())
  if (shots) await page.screenshot({ path: path.join(SHOTS, vp, `${kind}-profile.png`), fullPage: true })
  if (a11y) await axe(page, `${kind} profile`)
  await page.getByRole('radio', { name: new RegExp(roleName) }).first().click()
  const email = `qa.${kind}.${roleName.toLowerCase().replace(/\W+/g, '')}@example.com`
  await page.getByPlaceholder('Full name').fill(`QA ${roleName}`)
  await page.getByPlaceholder('Work email').fill(email)
  await page.getByPlaceholder('Company name').fill('QA Test Co')
  await page.getByRole('button', { name: /Start the assessment/ }).click()
  await page.waitForTimeout(500)

  let n = 0
  const progressOk = []
  while (n < 40) {
    const group = page.getByRole('radiogroup').first()
    if (!(await group.count())) break
    const nextBtn = page.getByRole('button', { name: /^(Next|See results)/ })
    const disabledBefore = await nextBtn.isDisabled()
    const opts = group.getByRole('radio')
    const count = await opts.count()
    const h1 = await page.locator('h1').count()
    const pb = await page.getByRole('progressbar').first().getAttribute('aria-valuenow')
    progressOk.push(disabledBefore && count === 5 && h1 === 1 && pb !== null)
    if (shots && n === 0) { await page.screenshot({ path: path.join(SHOTS, vp, `${kind}-question.png`), fullPage: true }) }
    if (a11y && n === 0) await axe(page, `${kind} question`)
    await opts.nth(pick(n, count)).click()
    n++
    const last = /See results/.test(await nextBtn.innerText())
    await nextBtn.click()
    await page.waitForTimeout(last ? 1200 : 350)
    if (last) break
  }
  ok(`${label}: answered ${n} questions`, n === 12, `${n}`)
  ok(`${label}: each question has 5 options, Next disabled until answered, one h1, progressbar`, progressOk.every(Boolean))
  const heading = await page.locator('h1').first().innerText().catch(() => '')
  ok(`${label}: results page`, /Your Results/i.test(heading), heading)
  const stageText = (await page.locator('body').innerText()).match(/Stage\s+\d/)?.[0] || ''
  if (shots) await page.screenshot({ path: path.join(SHOTS, vp, `${kind}-results.png`), fullPage: true })
  if (a11y) await axe(page, `${kind} results`)

  const before = mailFiles()
  await page.getByRole('button', { name: /Get full report/ }).first().click()
  await page.waitForTimeout(600)
  const emailField = page.getByPlaceholder('Work email *').last()
  ok(`${label}: report form pre-filled from profile`, (await emailField.inputValue()) === email)
  if (a11y) await axe(page, `${kind} report form`)
  await page.getByRole('checkbox').last().click()
  const respP = page.waitForResponse(r => r.url().includes('/api/assessment-report'), { timeout: 120000 })
  await page.locator('form button[type="submit"]').last().click()
  const apiRes = await respP.catch(() => null)
  ok(`${label}: report API responded 200`, apiRes?.status() === 200, `${apiRes?.status()}`)
  await page.waitForTimeout(1500)
  const after = mailFiles().filter(f => !before.includes(f))
  const msgs = after.map(f => JSON.parse(fs.readFileSync(path.join(MAIL_DIR, f), 'utf8')))
  ok(`${label}: 2 emails sent (respondent + team)`, msgs.length === 2, `${msgs.length}`)
  const R = ROUTING[assessment]
  const resp = msgs.find(m => decodeMime(header(m.raw, 'Subject')).startsWith('Your '))
  const team = msgs.find(m => decodeMime(header(m.raw, 'Subject')).startsWith('New '))
  if (resp) {
    const to = addrs(header(resp.raw, 'To')), cc = addrs(header(resp.raw, 'Cc'))
    const env = addrs(resp.rcpt.join(' '))
    const bcc = env.filter(a => !to.includes(a) && !cc.includes(a))
    ok(`${label}: respondent email To = respondent only`, sameSet(to, [email]) && cc.length === 0, `To=${to} Cc=${cc}`)
    ok(`${label}: respondent email BCC = approved list`, sameSet(bcc, R.bcc), `BCC=${bcc.join(', ')}`)
    ok(`${label}: BCC not exposed in headers`, !/^Bcc:/im.test(resp.raw))
    ok(`${label}: respondent subject`, decodeMime(header(resp.raw, 'Subject')) === `Your ${assessment} report from Radiant Digital`, decodeMime(header(resp.raw, 'Subject')))
    ok(`${label}: From = MAIL_FROM`, /connect@radiant\.digital/.test(header(resp.raw, 'From')))
    ok(`${label}: PDF attached`, /Content-Type: application\/pdf/i.test(resp.raw) && /filename="?[^"\r\n]*\.pdf/i.test(resp.raw) && bodyText(resp.raw).includes('%PDF'))
    ok(`${label}: sent over STARTTLS`, resp.tls === true)
  }
  if (team) {
    const to = addrs(header(team.raw, 'To')), cc = addrs(header(team.raw, 'Cc'))
    ok(`${label}: team email To = connect@ + hello@`, sameSet(to, R.teamTo), to.join(', '))
    ok(`${label}: team email CC = approved list`, sameSet(cc, R.teamCc), cc.join(', '))
    ok(`${label}: team subject`, decodeMime(header(team.raw, 'Subject')) === `New ${assessment} lead — QA ${roleName}`, decodeMime(header(team.raw, 'Subject')))
    ok(`${label}: team email carries lead details + PDF`, bodyText(team.raw).includes('QA Test Co') && /Consent to contact/.test(bodyText(team.raw)) && /application\/pdf/i.test(team.raw))
  }
  const body = await page.locator('body').innerText()
  ok(`${label}: on-page confirmation shows the email address`, body.includes(email))
  if (shots) await page.screenshot({ path: path.join(SHOTS, vp, `${kind}-report-sent.png`), fullPage: false })
  await page.context().close()
  return { stageText, files: after }
}

const allLow = () => 0, allHigh = (_, c) => c - 1, mixed = (i, c) => (i * 2) % c
await runAssessment({ kind: 'cx', roleName: 'Executive', pick: mixed, shots: true, a11y: true })
await runAssessment({ kind: 'cx', roleName: 'Practitioner', pick: allHigh })
await runAssessment({ kind: 'ai', roleName: 'Executive', pick: mixed, shots: true, a11y: true })
await runAssessment({ kind: 'cx', roleName: 'Practitioner', pick: allLow, vp: 'mobile', shots: true })
await runAssessment({ kind: 'ai', roleName: 'Executive', pick: allLow, vp: 'tablet', shots: true })

// ── 3. Header CTA from an assessment results page goes to /#assessment ──────
{
  const page = await newPage('desktop')
  await page.goto(BASE + '/assessment', { waitUntil: 'networkidle' })
  await page.screenshot({ path: path.join(SHOTS, 'desktop', 'assessment-hub.png'), fullPage: true })
  await axe(page, 'assessment hub')
  const cta = page.locator('a', { hasText: 'Assess Your AI and CX Readiness' }).first()
  if (await cta.count()) {
    await cta.click(); await page.waitForTimeout(1800)
    const top = await page.evaluate(() => Math.round(document.getElementById('assessment')?.getBoundingClientRect().top ?? 9999))
    ok('Header CTA from another route lands on /#assessment and scrolls', page.url().endsWith('/#assessment') && Math.abs(top) < 150, `${page.url()} top=${top}`)
  } else ok('Header CTA present on /assessment hub', false)
  await page.context().close()
}

// ── 4. Chat-embedded CX assessment still starts (role-tailored) ─────────────
{
  const page = await newPage('desktop')
  await page.goto(BASE + '/chat?q=' + encodeURIComponent('Assess my CX maturity'), { waitUntil: 'networkidle' })
  await page.waitForTimeout(2500)
  const intro = await page.locator('main').innerText()
  ok('Chat: CX answer uses the new 4-dimension, role-tailored description', /four dimensions: Strategy & Leadership, Insight & Understanding, Design & Delivery, and Culture & Accountability/.test(intro) && /10-12 min/.test(intro))
  await page.locator('main').getByText('CX Maturity Assessment', { exact: true }).first().click()
  await page.waitForTimeout(2500)
  const txt = await page.locator('main').innerText()
  ok('Chat: CX assessment profile card appears with role choice', /tailor your questions to your role/i.test(txt) && /Executive/.test(txt) && /Practitioner/.test(txt), txt.slice(-300).replace(/\s+/g, ' '))
  await page.context().close()
}

ok('No JavaScript errors in any page', errors.filter(e => !/favicon|net::ERR|Failed to load resource/i.test(e)).length === 0, errors.slice(0, 5).join(' | '))
fs.writeFileSync(path.join(SHOTS, '..', 'e2e-results.json'), JSON.stringify({ base: BASE, at: new Date().toISOString(), results, errors }, null, 2))
await browser.close()
const failed = results.filter(r => !r.pass).length
console.log(`\n${results.length - failed}/${results.length} checks passed`)
process.exit(failed ? 1 : 0)
