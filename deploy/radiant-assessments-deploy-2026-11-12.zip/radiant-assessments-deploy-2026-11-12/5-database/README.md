# Database: no changes required

**No SQL scripts, schema changes or migrations are included, because none are needed.**

What we checked in the code (`outputs/radiant-chat-api`, `outputs/ai-landing-v1`):

- Neither assessment reads from or writes to a database. Questions, answer options, scoring and report text are all in the website's JavaScript bundle (`src/data/aiAssessment.js`, `src/data/cxAssessment.js`).
- A submission is never stored. It exists only as two emails: the report sent to the respondent, and the "New … lead" email sent to the Radiant team. The PDF is attached to both.
- The Node API's dependencies (`package.json`) include no database driver. Its only persisted file is `config.json` (chat mode, AI/static), which this release does not touch.
- The PHP option (`3-backend-php`) also uses no database. Its rate limiter keeps small files in `RATE_LIMIT_DIR`.

So this deployment cannot affect production database data. We could not see the production SQL engine or version from this repository, and nothing here depends on it.

**If the business wants submissions stored** (for reporting, or as a backup if email fails), that's a new feature, not part of this release. It needs a decision on the fields, retention period and privacy notice, and a table designed for the confirmed engine and version. We haven't added a placeholder.
